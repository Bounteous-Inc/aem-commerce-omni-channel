;(function (angular, document, $http,  undefined) {

    angular.module('AEMAngularApp')

     	.controller('AccountsCtrl', ['$scope', '$http', 'phonegapReady', function($scope, $http, phonegapReady) {
//
//            $http.jsonp('http://mszulc.local:8089/telco?callback=JSON_CALLBACK').success(function (data) {
//    			console.log('Success', data);
//                $scope.accounts = data;
//  			})
        }]);
}(angular, document));