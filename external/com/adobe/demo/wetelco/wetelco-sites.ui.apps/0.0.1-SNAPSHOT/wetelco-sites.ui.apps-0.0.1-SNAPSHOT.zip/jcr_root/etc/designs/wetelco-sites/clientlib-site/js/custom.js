$(function(){
    $('.dropdown').hover(function() {
         $(this).toggleClass('open');
    });
});